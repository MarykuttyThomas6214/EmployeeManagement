package emp2.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Entity
//@Table(name = "EAccount")
public class EAccount {
	
	
	@Id
	private int acno;
	private int ifsc;
	private String branch;
	
	@ManyToMany(targetEntity = Employee.class, cascade = CascadeType.ALL)
	@JoinColumn(name= "ae_fk",referencedColumnName= "acno")
	private List<EAccount> accounts;

}
